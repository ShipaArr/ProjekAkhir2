Link Youtube presentasi Risam : https://youtu.be/3Y5OWmO5UPQ
Link Youtube Presentasi Hida : https://youtu.be/yJzN1XXvIMw?si=cApLosJvYxvv4Yqm
Link Youtube Presentasi Sipa : https://youtu.be/nyPHzGSjdFw?si=oD-VHyfKUUqx6DxQ
